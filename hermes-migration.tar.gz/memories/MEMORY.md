QQ私聊分段技巧：一句话一条消息。send_message在QQ私聊不可用。用terminal(command='true')在每句话之间做分隔符。原则：每个自然句都单独发，即使很短也要拆。
§
QQ私聊主动发消息方法：使用 QQ Bot API v2 的「互动召回消息」机制 —— POST /v2/users/{openid}/messages，请求体中设 "is_wakeup": true（不需要 msg_id/event_id）。限制：每周期（当天/1-3天/3-7天/7-30天）各 1 条，30 天最多 4 条。获取 access_token 用 POST https://bots.qq.com/app/getAppAccessToken，参数 appId + clientSecret。用户 openid 是 BF9451A527E791B2E62317E45E94BD16。
§
QQ主动私聊发消息：可通过QQ Bot API的is_wakeup互动召回机制实现。POST /v2/users/{openid}/messages，不带msg_id/event_id，设置is_wakeup:true。限额：当天/1-3天/3-7天/7-30天各1条，30天合计4条。比cron job方案干净（无系统标签）。access_token从POST https://bots.qq.com/app/getAppAccessToken获取。
§
用户当前运行在 WSL 沙盒环境中，宿主机是 Windows，有 NVIDIA GPU。WSL 内 nvidia-smi 不可用是沙盒限制，不代表没有显卡。如需 GPU 相关能力（ComfyUI 等），应在 Windows 宿主机上运行服务，然后从 WSL 内通过网络连接。
§
SOUL.md 在 ~/.hermes/SOUL.md（大写），包含 MiLe 的人设、语言规范、自我认知、QQ 私聊分段规则。用户要求遵守其中的分段规则：一句话一条消息，用 terminal(command='true') 做分隔符。
§
Hermes 的 env 文件受保护，不能用 patch/write_file 写入。追加内容必须通过 terminal 的 shell 重定向（cat >> 配合 heredoc）。
§
Claude Code 调用时使用 --effort max 参数