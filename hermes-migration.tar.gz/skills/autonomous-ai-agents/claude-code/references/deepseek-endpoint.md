# Claude Code via DeepSeek Anthropic Endpoint

DeepSeek provides an Anthropic-compatible API at `https://api.deepseek.com/anthropic`. This lets Claude Code run against DeepSeek's backend while using Anthropic model names — DeepSeek maps them to its own models internally.

## Quick Setup

```bash
# Install
npm install -g @anthropic-ai/claude-code

# Environment variables (in ~/.hermes/.env or export)
ANTHROPIC_BASE_URL=https://api.deepseek.com/anthropic
ANTHROPIC_AUTH_TOKEN=sk-your-deepseek-key
ANTHROPIC_MODEL=deepseek-v4-pro
ANTHROPIC_DEFAULT_HAIKU_MODEL=deepseek-v4-flash
ANTHROPIC_DEFAULT_SONNET_MODEL=deepseek-v4-pro
ANTHROPIC_DEFAULT_OPUS_MODEL=deepseek-v4-pro
ENABLE_TOOL_SEARCH=true
```

Note: use `ANTHROPIC_AUTH_TOKEN` (not `ANTHROPIC_API_KEY`) for DeepSeek's endpoint.

## Settings File (`~/.claude/settings.json`)

```json
{
  "env": {
    "ANTHROPIC_BASE_URL": "https://api.deepseek.com/anthropic",
    "ANTHROPIC_AUTH_TOKEN": "sk-your-key",
    "ANTHROPIC_MODEL": "deepseek-v4-pro",
    "ANTHROPIC_DEFAULT_HAIKU_MODEL": "deepseek-v4-flash",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "deepseek-v4-pro",
    "ANTHROPIC_DEFAULT_OPUS_MODEL": "deepseek-v4-pro",
    "ENABLE_TOOL_SEARCH": "true"
  },
  "model": "opus[1m]",
  "effortLevel": "max"
}
```

The `env` block in settings.json is loaded by Claude Code at startup — no need to export manually each time.

## Model Mapping

Claude Code only knows Anthropic model names. You CANNOT pass `deepseek-v4-pro` via `--model`. The mapping is done via the env vars above, which DeepSeek's endpoint reads to route requests.

For the `--effort` flag: Claude Code sets reasoning effort. Max is recommended when using DeepSeek's reasoning-capable models.

## Verifying

```bash
claude -p "Say hello, what model are you?" --max-turns 1 --output-format json
```

Check the `modelUsage` field in the JSON output to see which underlying model handled the request.
