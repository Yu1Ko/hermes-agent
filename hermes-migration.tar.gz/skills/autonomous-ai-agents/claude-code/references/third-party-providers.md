# Third-Party Anthropic-Compatible Providers

Some providers expose an Anthropic-compatible API endpoint that Claude Code can use directly.

## DeepSeek

DeepSeek provides an Anthropic-compatible endpoint at `https://api.deepseek.com/anthropic`.

### Setup

```bash
export ANTHROPIC_BASE_URL=https://api.deepseek.com/anthropic
export ANTHROPIC_API_KEY=sk-xxxxxxxxxxxxxxxx
```

### Verified

- Claude Code v2.1.126 connects successfully
- Reports model as `claude-sonnet-4-6` (DeepSeek maps to Claude model names)
- Cost: ~$0.07 for a simple one-turn query (~23k input tokens + 91 output)

### Persistence

Add to `~/.hermes/.env` so Claude Code picks them up when spawned:

```bash
ANTHROPIC_BASE_URL=https://api.deepseek.com/anthropic
ANTHROPIC_API_KEY=sk-xxxxxxxxxxxxxxxx
```

### Pitfalls

- The `.env` file is protected by Hermes — use `terminal` with `cat >>` to append, not `patch`/`write_file`
- Model names may differ from what you expect — DeepSeek's endpoint maps to Claude model identifiers
- Always verify with `claude -p "hello" --max-turns 1 --output-format json` after setup
