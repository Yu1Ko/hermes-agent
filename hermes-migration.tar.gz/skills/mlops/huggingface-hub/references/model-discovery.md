# AI Model Discovery via REST APIs

Quick patterns for finding whether an organization released a new model, without needing browser or `hf` CLI.

## GitHub Org API — find newest repos

```bash
curl -sL "https://api.github.com/orgs/{ORG}/repos?sort=updated&per_page=15&type=public" \
  | python3 -c "
import json, sys
for r in json.load(sys.stdin)[:15]:
    desc = r.get('description', '') or ''
    print(f\"{r['name']:30s} ⭐{r['stargazers_count']:>6}  updated:{r['updated_at'][:10]}  {desc[:80]}\")
"
```

Common orgs: `deepseek-ai`, `meta-llama`, `QwenLM`, `THUDM`, `01-ai`, `anthropics`

## HuggingFace API — find newest models by author

```bash
curl -sL "https://huggingface.co/api/models?author={AUTHOR}&sort=lastModified&direction=-1&limit=10" \
  | python3 -c "
import json, sys
for m in json.load(sys.stdin)[:10]:
    tags = m.get('pipeline_tag', 'N/A')
    print(f\"{m['modelId']:45s}  {m['lastModified'][:10]}  downloads:{m.get('downloads','?'):>10}  {tags}\")
"
```

The `pipeline_tag` field reveals the model type:
- `text-generation` → LLM
- `image-text-to-text` → vision-language / OCR
- `image-generation` → diffusion models
- `automatic-speech-recognition` → ASR

## Filter by model type

To find vision models specifically, filter on keywords:

```bash
curl -sL "https://api.github.com/orgs/{ORG}/repos?per_page=50&type=public" \
  | python3 -c "
import json, sys
vision_kw = ['vision', 'visual', 'vl', 'janus', 'multimodal', 'ocr', 'image', 'video']
for r in json.load(sys.stdin):
    name = r['name'].lower()
    desc = (r.get('description') or '').lower()
    if any(k in name or k in desc for k in vision_kw):
        print(f\"{r['name']:30s} ⭐{r['stargazers_count']:>6}  created:{r['created_at'][:10]}  {r.get('description','')[:100]}\")
"
```

## Single repo details

```bash
curl -sL "https://api.github.com/repos/{ORG}/{REPO}" \
  | python3 -c "
import json, sys
r = json.load(sys.stdin)
print(f\"{r['name']}  ⭐{r['stargazers_count']}  created:{r['created_at'][:10]}  pushed:{r['pushed_at'][:10]}\")
print(f\"{r.get('description', 'N/A')}\")
"
```

## Pitfalls

- **Google CAPTCHA**: If browser search gets blocked, skip it — go directly to GitHub/HuggingFace APIs via `curl`. These APIs don't have bot detection.
- **HF API rate limits**: The public HuggingFace API is rate-limited. Use `hf` CLI with auth for heavy queries.
- **GitHub API rate limits**: Unauthenticated requests are limited to 60/hr. Authenticated gets 5000/hr.
